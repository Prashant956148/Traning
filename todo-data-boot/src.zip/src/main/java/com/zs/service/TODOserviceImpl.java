package com.zs.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zs.entity.TODO;

import com.zs.entity.User;
import com.zs.repo.Todorepo;

import jakarta.transaction.Transactional;

@Service
public class TODOserviceImpl implements TODOService {
@Autowired
private Todorepo repo;
@Autowired
private UserService users;
	@Override
	
	public void save(TODO t,int id) {
		User u=users.fetch(id);
		t.setUser(u);
		
		t.setStatus("pending");
			repo.save(t);
		

	}

	@Override
	
	public void update(int id) {
		TODO t=fetch(id);
		t.setStatus("completed");
		
		repo.save(t);
		
	}

	@Override
	public TODO fetch(int id) {
		return repo.findById(id).get();
		
	}

	@Override
	public void Delete(int id) {
		 repo.deleteById(id);
		
	}

}
