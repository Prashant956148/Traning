package com.zs.service;

import com.zs.entity.TODO;

public interface TODOService {
void save(TODO t,int id);
public void update(int id);
public TODO fetch(int id);
public void Delete(int id);

	
}
