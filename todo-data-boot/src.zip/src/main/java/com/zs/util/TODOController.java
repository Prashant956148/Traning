package com.zs.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zs.entity.TODO;
import com.zs.service.TODOService;



@RestController
@RequestMapping("/TODO")
public class TODOController {
@Autowired
private TODOService service;
	@PostMapping(value="/save/{id}",consumes = "application/json")
	public String save(@RequestBody TODO t,@PathVariable int id) {
	service.save(t,id);
	return "TODO saved";
	}
	@GetMapping(value="/fetch/{id}",produces = "application/json")
	public TODO fetch(@PathVariable int id) {
		return service.fetch(id);
	}
	
	@DeleteMapping("/delete/{id}")
	public void delete(@PathVariable int id) {
		 service.Delete(id);
	}
}
